require("dotenv").config();
const express = require("express");
const cors = require("cors");
const conectarDB = require("./config/db");

const authRoutes = require("./routes/auth.routes");
const userRoutes = require("./routes/user.routes");
const courseRoutes = require("./routes/course.routes");
const enrollmentRoutes = require("./routes/enrollment.routes");

// conectar a la base de datos
conectarDB();

const app = express();

// middlewares
app.use(cors());
app.use(express.json());

// log de rutas solicitadas (como el profe lo hizo en clase)
app.use((req, res, next) => {
    console.log(`Ruta solicitada: ${req.method} ${req.url}`);
    next();
});

// rutas
app.use("/api/auth", authRoutes);
app.use("/api/usuarios", userRoutes);
app.use("/api/cursos", courseRoutes);
app.use("/api/inscripciones", enrollmentRoutes);

app.get("/", (req, res) => {
    res.json({ mensaje: "API de Gestion de Cursos e Inscripciones funcionando" });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});

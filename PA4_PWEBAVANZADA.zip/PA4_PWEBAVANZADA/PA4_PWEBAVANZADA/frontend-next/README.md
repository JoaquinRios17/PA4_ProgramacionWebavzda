Instalación

cd al terminal de backend
npm install
cp .env.example .env
npm run dev

cd al terminal de frontend-next
npm install
cp .env.example .env
npm run dev

cd al terminal frontend-react
npm install
cp .env.example .env
npm run dev

Tecnologías usadas

- Next.js 16 con App Router
- TypeScript
- Tailwind CSS


Backend http://localhost:3000
React http://localhost:5173
Next.js http://localhost:3001

El backend debe estar corriendo antes de usar este frontend.

Integrantes

-Hector Joaquin
Desarrollo Backend
API REST y rutas públicas para Next.js

-Ricardo Alejandro
Desarrollo Frontend
Login, Context de autenticación y rutas protegidas

-Jair Santiago
Desarrollo Frontend
Catálogo de cursos, detalle e inscripción

-Joustin Edgar
Desarrollo Frontend
Catálogo público y detalle dinámico en Next.js con SSR

Enlace a video de youtube: https://youtu.be/YjUHhLC1XiI?si=1wzQa9hukYZRx6i9

Enlace al repositorio en github: https://github.com/JoaquinRios17/PA4_ProgramacionWebavzda.git